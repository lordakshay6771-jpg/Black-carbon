<?php

$GEMINI_API_KEY = "AQ.Ab8RN6L9U-_7xe14Akh0OUHLVsXXcIthuB3WwojIwgzawWnm2w";
$GEMINI_MODEL = "gemini-3.5-flash-lite";

?>